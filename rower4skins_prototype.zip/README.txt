
Rower4Skins Prototype
=====================

Plik HTML to prosty prototyp działający lokalnie (bez backendu, bez Steam, bez prawdziwych transakcji).
Uruchomienie:
1. Pobierz rozpakuj plik ZIP.
2. Otwórz `index.html` w przeglądarce (najlepiej Chrome/Edge/Firefox).
3. Strona używa localStorage do zapisu stanu (kredyty, ekwipunek), możesz zresetować przez wyczyszczenie localStorage.

Uwaga:
- To tylko symulator/wygląd, nie jest to działający serwis hazardowy.
- Nie używaj do prawdziwych transakcji.
